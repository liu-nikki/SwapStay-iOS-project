//
//  Utilities.swift
//  WA4_Liu_8556
//
//  Created by Nikki Liu on 10/2/23.
//

import Foundation

class Utilities{
    static let types = ["Cell", "Work", "Home"]
}
